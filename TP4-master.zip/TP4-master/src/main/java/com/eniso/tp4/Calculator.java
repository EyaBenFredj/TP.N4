
package com.eniso.tp4;


public class Calculator {
    public int add(int num1, int num2){
        return num1 + num2 ;
    }
    public int add(int num1 , int num2 ,int num3){
        return num1+ num2 + num3;
    }
    public double add(double num1 , double num2){
        return num1 + num2;
    }
    public String add(String str1 , String str2){
        return str1 + str2 ;
    }
    
    
}
