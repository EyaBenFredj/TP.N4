
package com.eniso.tp4;

public enum Classe {
    IA1_1,
    IA1_2,
    GTE1

}
