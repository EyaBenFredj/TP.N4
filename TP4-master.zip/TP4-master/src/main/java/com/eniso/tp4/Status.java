
package com.eniso.tp4;

public enum Status {
    REDOUBLANT,
    NON_REDOUBLANT
}
